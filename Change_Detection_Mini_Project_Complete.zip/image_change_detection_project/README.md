# Change Detection Between Two Images Taken at Different Times

## Project overview
This mini project compares an earlier image and a later image of the same scene. It uses grayscale conversion, absolute pixel difference, thresholding, morphological cleanup, and contour boxes to highlight changed regions.

## Requirements
- Python 3.9 or later
- OpenCV
- NumPy

Install dependencies:
```bash
pip install opencv-python numpy
```

## Run
From the project folder:
```bash
python change_detection.py --before sample_images/image_before.png --after sample_images/image_after.png
```

Outputs are written to `outputs/`:
- `difference_image.png` — grayscale pixel-difference map
- `change_mask.png` — binary map of candidate changed pixels
- `highlighted_changes.png` — later image with red boxes around detected regions

Optional parameters:
```bash
python change_detection.py --before sample_images/image_before.png --after sample_images/image_after.png --threshold 30 --min-area 100
```

## Important notes
- The sample images are synthetic illustrations created for this project, not real field data.
- For meaningful comparisons, use images of the same scene with similar viewpoint, dimensions, and lighting.
- Resizing alone does not align images with different camera angles.
- The reported percentage is the fraction of white pixels in the processed mask; it is not a validated accuracy score or proof of real-world change.

## Suggested demo
1. Run the command above.
2. Open `outputs/highlighted_changes.png`.
3. Explain why the car/object appearing in the second image is highlighted.
4. Change the threshold (e.g., 15, 25, 40) and compare the masks.
