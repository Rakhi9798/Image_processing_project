"""
Mini Project: Detecting Changes Between Two Images Taken at Different Times
Student project using Python, OpenCV, and NumPy.

Run:
    pip install opencv-python numpy
    python change_detection.py --before sample_images/image_before.png --after sample_images/image_after.png

Outputs are saved in the outputs/ folder.
"""
import argparse
from pathlib import Path
import cv2
import numpy as np


def detect_changes(before_path, after_path, output_dir="outputs",
                   threshold=25, min_area=80):
    """Compare two images and save a difference map, binary mask, and overlay."""
    before_path, after_path = Path(before_path), Path(after_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    img1 = cv2.imread(str(before_path))
    img2 = cv2.imread(str(after_path))
    if img1 is None:
        raise FileNotFoundError(f"Could not read first image: {before_path}")
    if img2 is None:
        raise FileNotFoundError(f"Could not read second image: {after_path}")

    # Resize image 2 to image 1's dimensions if their sizes differ.
    # This is a convenience, not a substitute for geometric alignment.
    if img1.shape[:2] != img2.shape[:2]:
        img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

    gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

    # Absolute pixel-wise difference; larger values indicate larger differences.
    difference = cv2.absdiff(gray1, gray2)

    # Reduce tiny noise, then threshold the difference into a binary mask.
    blurred = cv2.GaussianBlur(difference, (5, 5), 0)
    _, mask = cv2.threshold(blurred, threshold, 255, cv2.THRESH_BINARY)

    # Remove small isolated dots and connect nearby changed pixels.
    kernel = np.ones((3, 3), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    mask = cv2.dilate(mask, kernel, iterations=2)

    # Draw boxes around sufficiently large changed regions.
    overlay = img2.copy()
    contours, _ = cv2.findContours(
        mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )
    for contour in contours:
        if cv2.contourArea(contour) >= min_area:
            x, y, w, h = cv2.boundingRect(contour)
            cv2.rectangle(overlay, (x, y), (x + w, y + h), (0, 0, 255), 2)

    cv2.imwrite(str(output_dir / "difference_image.png"), difference)
    cv2.imwrite(str(output_dir / "change_mask.png"), mask)
    cv2.imwrite(str(output_dir / "highlighted_changes.png"), overlay)

    changed_pixels = int(np.count_nonzero(mask))
    total_pixels = int(mask.size)
    changed_percent = 100.0 * changed_pixels / total_pixels

    print("Change detection completed.")
    print(f"Image dimensions: {img1.shape[1]} x {img1.shape[0]}")
    print(f"Changed mask pixels: {changed_pixels} / {total_pixels}")
    print(f"Changed-pixel percentage after mask processing: {changed_percent:.2f}%")
    print(f"Outputs saved to: {output_dir.resolve()}")
    return changed_percent


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Compare two images over time.")
    parser.add_argument("--before", required=True, help="Earlier image path")
    parser.add_argument("--after", required=True, help="Later image path")
    parser.add_argument("--out", default="outputs", help="Output directory")
    parser.add_argument("--threshold", type=int, default=25,
                        help="Pixel difference threshold (default: 25)")
    parser.add_argument("--min-area", type=int, default=80,
                        help="Minimum contour area to draw a box")
    args = parser.parse_args()
    detect_changes(args.before, args.after, args.out, args.threshold, args.min_area)
